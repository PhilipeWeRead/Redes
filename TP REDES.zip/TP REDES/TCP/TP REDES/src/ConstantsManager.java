
public class ConstantsManager {
	public static int Port = 6700;
	public static int MaxShop = 60;
	public static int MaxItem = 22170;
	public static int InstanceCount = 2935849;
}
